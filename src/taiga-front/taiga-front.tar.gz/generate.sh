git checkout stable; node dist.js stable

